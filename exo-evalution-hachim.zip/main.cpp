/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <math.h>
using namespace std;

int main(){
int val1,val2,som,i,D,compt;
compt=0;
som=0;
cout<<"saisir val1"<<endl;
cin>> val1;
cout<<"saisir val2"<<endl;
cin>> val2;
while(val1>=val2){
     cout<<"val1 doit etre inferieur.resaisi"<<endl;
     cout<<"saisir val1"<<endl;
     cin>> val1;
     cout<<"saisir val2"<<endl;
     cin>> val2;
   }
cout<<"saisir D"<<endl;
cin>>D;
for(i=val1;i<=val2;i++){
     if(i%D==0){
         compt=compt+1;
         som=som+i;
     }
}
cout<<"le nombre de multiple de D est"<<compt<<endl;
cout<<"la somme des multiples de D est"<<som<<endl;

 return 0;
}

